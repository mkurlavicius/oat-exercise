# OAT -Technical Exercise

### Mindaugas Kurlavicius

The task was completed with Laravel Web Framework.

1. I had a working project instance on my machine.
2. Decided to use csv seeder, a plugin that easily inserts
csv to database (MySQL). It can be reused for multiple csv files. 
3. Got then benefit, that providing PersonController could make
the whole REST'full API of the users.
4. Filtering (paginating) required a special query. So the index action on
person controller had to be more sophisticated.
5. Started the project with a User model present, so instead of "fixing" that
used person - people inside application. Some cleanup would be nice, but times up.
